
<?php
$country = $_GET['country'];
$firstname = $_GET['firstname'];
$lastname = $_GET['lastname'];
echo " $firstname , $lastname Thank you for reaching I will get back you shortly.. <br>";
?>
 