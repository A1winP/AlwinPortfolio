<?php
    $name=$_POST['name'];
    $age=$_POST['age'];
    $city=$_POST['city'];
  
    echo "NAME-SUBMITTED : $name <br>";
  
    echo "AGE-SUBMITTED :  $age <br>";
  
    echo "CITY-SUBMITTED:  $city";
?>